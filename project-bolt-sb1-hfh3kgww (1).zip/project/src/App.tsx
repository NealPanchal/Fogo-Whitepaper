import React, { useState } from 'react';
import { Globe, FileText, ChevronDown } from 'lucide-react';
import { introductionContent, outlineContent, protocolClientsContent, firedancerContent, clientDiversityContent, protocolIncentivesContent, multiLocalConsensusContent } from './content';

const App = () => {
  const [selectedLanguage, setSelectedLanguage] = useState('english');
  const [selectedSection, setSelectedSection] = useState('1');
  const [selectedSubsection, setSelectedSubsection] = useState('');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const languages = [
    { code: 'english', name: 'English', nativeName: 'English' },
    { code: 'vietnamese', name: 'Vietnamese', nativeName: 'Tiếng Việt' },
    { code: 'indonesian', name: 'Indonesian', nativeName: 'Bahasa Indonesia' },
    { code: 'malaysian', name: 'Malaysian', nativeName: 'Bahasa Malaysia' },
    { code: 'chinese', name: 'Chinese', nativeName: '中文' },
    { code: 'thai', name: 'Thai', nativeName: 'ไทย' },
    { code: 'hindi', name: 'Hindi', nativeName: 'हिन्दी' },
    { code: 'japanese', name: 'Japanese', nativeName: '日本語' },
    { code: 'korean', name: 'Korean', nativeName: '한국어' },
    { code: 'filipino', name: 'Filipino', nativeName: 'Filipino' },
    { code: 'ukrainian', name: 'Ukrainian', nativeName: 'Українська' },
    { code: 'portuguese', name: 'Portuguese', nativeName: 'Português' },
    { code: 'french', name: 'French', nativeName: 'Français' },
    { code: 'turkish', name: 'Turkish', nativeName: 'Türkçe' },
    { code: 'russian', name: 'Russian', nativeName: 'Русский' },
    { code: 'hausa', name: 'Hausa', nativeName: 'Hausa' },
    { code: 'spanish', name: 'Spanish', nativeName: 'Español' },
    { code: 'bengali', name: 'Bengali', nativeName: 'বাংলা' },
    { code: 'urdu', name: 'Urdu', nativeName: 'اردو' },
    { code: 'polish', name: 'Polish', nativeName: 'Polski' },
    { code: 'arabic', name: 'Arabic', nativeName: 'العربية' },
    { code: 'persian', name: 'Persian', nativeName: 'فارسی' }
  ];

  const translations = {
    english: {
      title: 'Fogo White Paper Translation Website',
      subtitle: 'Access the Fogo blockchain white paper in your preferred language',
      selectLanguage: 'Select Language',
      selectSection: 'Select Section',
      sections: {
        '1': '1. Introduction',
        '2': '2. Outline',
        '3': '3. Protocol and Clients',
        '4': '4. Multi-Local Consensus',
        '5': '5. Validator Set',
        '6': '6. Prospective Extensions',
        '7': '7. Conclusion'
      },
      subsections: {
        '3': {
          '3.1': '3.1 Firedancer',
          '3.2': '3.2 Canonical Clients vs. Client Diversity',
          '3.3': '3.3 Protocol Incentives for Performant Clients'
        },
        '4': {
          '4.1': '4.1 Zones and Zone Rotation',
          '4.2': '4.2 Key Management',
          '4.3': '4.3 Zone Proposal and Activation',
          '4.4': '4.4 Zone Selection Voting Process',
          '4.5': '4.5 Global Consensus Mode'
        },
        '5': {
          '5.1': '5.1 Size and Initial Configuration',
          '5.2': '5.2 Governance and Transitions',
          '5.3': '5.3 Participation Requirements',
          '5.4': '5.4 Rationale and Network Governance'
        },
        '6': {
          '6.1': '6.1 SPL Token Fee Payment'
        }
      }
    },
    vietnamese: {
      title: 'Trang Web Dịch Thuật Sách Trắng Fogo',
      subtitle: 'Truy cập sách trắng blockchain Fogo bằng ngôn ngữ ưa thích của bạn',
      selectLanguage: 'Chọn Ngôn Ngữ',
      selectSection: 'Chọn Phần',
      sections: {
        '1': '1. Giới Thiệu',
        '2': '2. Đề Cương',
        '3': '3. Giao Thức và Khách Hàng',
        '4': '4. Đồng Thuận Đa Địa Phương',
        '5': '5. Tập Hợp Validator',
        '6': '6. Phần Mở Rộng Tương Lai',
        '7': '7. Kết Luận'
      },
      subsections: {
        '3': {
          '3.1': '3.1 Firedancer',
          '3.2': '3.2 Khách Hàng Chính Thức vs. Đa Dạng Khách Hàng',
          '3.3': '3.3 Khuyến Khích Giao Thức cho Khách Hàng Hiệu Suất'
        },
        '4': {
          '4.1': '4.1 Vùng và Xoay Vùng',
          '4.2': '4.2 Quản Lý Khóa',
          '4.3': '4.3 Đề Xuất và Kích Hoạt Vùng',
          '4.4': '4.4 Quy Trình Bỏ Phiếu Chọn Vùng',
          '4.5': '4.5 Chế Độ Đồng Thuận Toàn Cầu'
        },
        '5': {
          '5.1': '5.1 Kích Thước và Cấu Hình Ban Đầu',
          '5.2': '5.2 Quản Trị và Chuyển Đổi',
          '5.3': '5.3 Yêu Cầu Tham Gia',
          '5.4': '5.4 Lý Do và Quản Trị Mạng'
        },
        '6': {
          '6.1': '6.1 Thanh Toán Phí Token SPL'
        }
      }
    },
    indonesian: {
      title: 'Situs Web Terjemahan White Paper Fogo',
      subtitle: 'Akses white paper blockchain Fogo dalam bahasa pilihan Anda',
      selectLanguage: 'Pilih Bahasa',
      selectSection: 'Pilih Bagian',
      sections: {
        '1': '1. Pengantar',
        '2': '2. Garis Besar',
        '3': '3. Protokol dan Klien',
        '4': '4. Konsensus Multi-Lokal',
        '5': '5. Set Validator',
        '6': '6. Ekstensi Prospektif',
        '7': '7. Kesimpulan'
      },
      subsections: {
        '3': {
          '3.1': '3.1 Firedancer',
          '3.2': '3.2 Klien Kanonik vs. Keragaman Klien',
          '3.3': '3.3 Insentif Protokol untuk Klien Berkinerja'
        },
        '4': {
          '4.1': '4.1 Zona dan Rotasi Zona',
          '4.2': '4.2 Manajemen Kunci',
          '4.3': '4.3 Proposal dan Aktivasi Zona',
          '4.4': '4.4 Proses Voting Seleksi Zona',
          '4.5': '4.5 Mode Konsensus Global'
        },
        '5': {
          '5.1': '5.1 Ukuran dan Konfigurasi Awal',
          '5.2': '5.2 Tata Kelola dan Transisi',
          '5.3': '5.3 Persyaratan Partisipasi',
          '5.4': '5.4 Rasional dan Tata Kelola Jaringan'
        },
        '6': {
          '6.1': '6.1 Pembayaran Biaya Token SPL'
        }
      }
    },
    malaysian: {
      title: 'Laman Web Terjemahan Kertas Putih Fogo',
      subtitle: 'Akses kertas putih blockchain Fogo dalam bahasa pilihan anda',
      selectLanguage: 'Pilih Bahasa',
      selectSection: 'Pilih Bahagian',
      sections: {
        '1': '1. Pengenalan',
        '2': '2. Garis Panduan',
        '3': '3. Protokol dan Klien',
        '4': '4. Konsensus Multi-Tempatan',
        '5': '5. Set Pengesah',
        '6': '6. Sambungan Prospektif',
        '7': '7. Kesimpulan'
      },
      subsections: {
        '3': {
          '3.1': '3.1 Firedancer',
          '3.2': '3.2 Klien Kanonik vs. Kepelbagaian Klien',
          '3.3': '3.3 Insentif Protokol untuk Klien Berprestasi'
        },
        '4': {
          '4.1': '4.1 Zon dan Putaran Zon',
          '4.2': '4.2 Pengurusan Kunci',
          '4.3': '4.3 Cadangan dan Pengaktifan Zon',
          '4.4': '4.4 Proses Pengundian Pemilihan Zon',
          '4.5': '4.5 Mod Konsensus Global'
        },
        '5': {
          '5.1': '5.1 Saiz dan Konfigurasi Awal',
          '5.2': '5.2 Tadbir Urus dan Peralihan',
          '5.3': '5.3 Keperluan Penyertaan',
          '5.4': '5.4 Rasional dan Tadbir Urus Rangkaian'
        },
        '6': {
          '6.1': '6.1 Pembayaran Yuran Token SPL'
        }
      }
    },
    chinese: {
      title: 'Fogo白皮书翻译网站',
      subtitle: '以您的首选语言访问Fogo区块链白皮书',
      selectLanguage: '选择语言',
      selectSection: '选择章节',
      sections: {
        '1': '1. 介绍',
        '2': '2. 大纲',
        '3': '3. 协议和客户端',
        '4': '4. 多本地共识',
        '5': '5. 验证器集',
        '6': '6. 前瞻性扩展',
        '7': '7. 结论'
      },
      subsections: {
        '3': {
          '3.1': '3.1 Firedancer',
          '3.2': '3.2 规范客户端 vs. 客户端多样性',
          '3.3': '3.3 高性能客户端的协议激励'
        },
        '4': {
          '4.1': '4.1 区域和区域轮换',
          '4.2': '4.2 密钥管理',
          '4.3': '4.3 区域提案和激活',
          '4.4': '4.4 区域选择投票过程',
          '4.5': '4.5 全局共识模式'
        },
        '5': {
          '5.1': '5.1 规模和初始配置',
          '5.2': '5.2 治理和转换',
          '5.3': '5.3 参与要求',
          '5.4': '5.4 理由和网络治理'
        },
        '6': {
          '6.1': '6.1 SPL代币费用支付'
        }
      }
    },
    thai: {
      title: 'เว็บไซต์แปลเอกสารสีขาว Fogo',
      subtitle: 'เข้าถึงเอกสารสีขาวบล็อกเชน Fogo ในภาษาที่คุณต้องการ',
      selectLanguage: 'เลือกภาษา',
      selectSection: 'เลือกส่วน',
      sections: {
        '1': '1. บทนำ',
        '2': '2. โครงร่าง',
        '3': '3. โปรโตคอลและไคลเอนต์',
        '4': '4. ฉันทามติหลายท้องถิ่น',
        '5': '5. ชุดตัวตรวจสอบ',
        '6': '6. ส่วนขยายในอนาคต',
        '7': '7. บทสรุป'
      },
      subsections: {
        '3': {
          '3.1': '3.1 Firedancer',
          '3.2': '3.2 ไคลเอนต์มาตรฐาน vs. ความหลากหลายของไคลเอนต์',
          '3.3': '3.3 แรงจูงใจโปรโตคอลสำหรับไคลเอนต์ประสิทธิภาพสูง'
        },
        '4': {
          '4.1': '4.1 โซนและการหมุนโซน',
          '4.2': '4.2 การจัดการคีย์',
          '4.3': '4.3 ข้อเสนอและการเปิดใช้งานโซน',
          '4.4': '4.4 กระบวนการโหวตเลือกโซน',
          '4.5': '4.5 โหมดฉันทามติทั่วโลก'
        },
        '5': {
          '5.1': '5.1 ขนาดและการกำหนดค่าเริ่มต้น',
          '5.2': '5.2 การกำกับดูแลและการเปลี่ยนแปลง',
          '5.3': '5.3 ข้อกำหนดการมีส่วนร่วม',
          '5.4': '5.4 เหตุผลและการกำกับดูแลเครือข่าย'
        },
        '6': {
          '6.1': '6.1 การชำระค่าธรรมเนียมโทเค็น SPL'
        }
      }
    },
    hindi: {
      title: 'फोगो व्हाइट पेपर अनुवाद वेबसाइट',
      subtitle: 'अपनी पसंदीदा भाषा में फोगो ब्लॉकचेन व्हाइट पेपर तक पहुंचें',
      selectLanguage: 'भाषा चुनें',
      selectSection: 'अनुभाग चुनें',
      sections: {
        '1': '1. परिचय',
        '2': '2. रूपरेखा',
        '3': '3. प्रोटोकॉल और क्लाइंट',
        '4': '4. बहु-स्थानीय सहमति',
        '5': '5. वैलिडेटर सेट',
        '6': '6. भावी विस्तार',
        '7': '7. निष्कर्ष'
      },
      subsections: {
        '3': {
          '3.1': '3.1 Firedancer',
          '3.2': '3.2 कैनोनिकल क्लाइंट vs. क्लाइंट विविधता',
          '3.3': '3.3 प्रदर्शनकारी क्लाइंट के लिए प्रोटोकॉल प्रोत्साहन'
        },
        '4': {
          '4.1': '4.1 जोन और जोन रोटेशन',
          '4.2': '4.2 की प्रबंधन',
          '4.3': '4.3 जोन प्रस्ताव और सक्रियण',
          '4.4': '4.4 जोन चयन मतदान प्रक्रिया',
          '4.5': '4.5 वैश्विक सहमति मोड'
        },
        '5': {
          '5.1': '5.1 आकार और प्रारंभिक कॉन्फ़िगरेशन',
          '5.2': '5.2 शासन और संक्रमण',
          '5.3': '5.3 भागीदारी आवश्यकताएं',
          '5.4': '5.4 तर्क और नेटवर्क शासन'
        },
        '6': {
          '6.1': '6.1 SPL टोकन शुल्क भुगतान'
        }
      }
    },
    japanese: {
      title: 'Fogoホワイトペーパー翻訳ウェブサイト',
      subtitle: 'お好みの言語でFogoブロックチェーンホワイトペーパーにアクセス',
      selectLanguage: '言語を選択',
      selectSection: 'セクションを選択',
      sections: {
        '1': '1. 序論',
        '2': '2. 概要',
        '3': '3. プロトコルとクライアント',
        '4': '4. マルチローカルコンセンサス',
        '5': '5. バリデータセット',
        '6': '6. 将来の拡張',
        '7': '7. 結論'
      },
      subsections: {
        '3': {
          '3.1': '3.1 Firedancer',
          '3.2': '3.2 正規クライアント vs. クライアントの多様性',
          '3.3': '3.3 高性能クライアントのプロトコルインセンティブ'
        },
        '4': {
          '4.1': '4.1 ゾーンとゾーンローテーション',
          '4.2': '4.2 キー管理',
          '4.3': '4.3 ゾーン提案と活性化',
          '4.4': '4.4 ゾーン選択投票プロセス',
          '4.5': '4.5 グローバルコンセンサスモード'
        },
        '5': {
          '5.1': '5.1 サイズと初期設定',
          '5.2': '5.2 ガバナンスと移行',
          '5.3': '5.3 参加要件',
          '5.4': '5.4 根拠とネットワークガバナンス'
        },
        '6': {
          '6.1': '6.1 SPLトークン手数料支払い'
        }
      }
    },
    korean: {
      title: 'Fogo 백서 번역 웹사이트',
      subtitle: '선호하는 언어로 Fogo 블록체인 백서에 액세스하세요',
      selectLanguage: '언어 선택',
      selectSection: '섹션 선택',
      sections: {
        '1': '1. 소개',
        '2': '2. 개요',
        '3': '3. 프로토콜과 클라이언트',
        '4': '4. 다중 로컬 합의',
        '5': '5. 검증자 세트',
        '6': '6. 향후 확장',
        '7': '7. 결론'
      },
      subsections: {
        '3': {
          '3.1': '3.1 Firedancer',
          '3.2': '3.2 표준 클라이언트 vs. 클라이언트 다양성',
          '3.3': '3.3 고성능 클라이언트를 위한 프로토콜 인센티브'
        },
        '4': {
          '4.1': '4.1 존과 존 로테이션',
          '4.2': '4.2 키 관리',
          '4.3': '4.3 존 제안 및 활성화',
          '4.4': '4.4 존 선택 투표 프로세스',
          '4.5': '4.5 글로벌 합의 모드'
        },
        '5': {
          '5.1': '5.1 크기 및 초기 구성',
          '5.2': '5.2 거버넌스 및 전환',
          '5.3': '5.3 참여 요구사항',
          '5.4': '5.4 근거 및 네트워크 거버넌스'
        },
        '6': {
          '6.1': '6.1 SPL 토큰 수수료 지불'
        }
      }
    },
    filipino: {
      title: 'Fogo White Paper Translation Website',
      subtitle: 'I-access ang Fogo blockchain white paper sa inyong preferred na wika',
      selectLanguage: 'Pumili ng Wika',
      selectSection: 'Pumili ng Seksyon',
      sections: {
        '1': '1. Panimula',
        '2': '2. Balangkas',
        '3': '3. Protocol at Clients',
        '4': '4. Multi-Local Consensus',
        '5': '5. Validator Set',
        '6': '6. Prospective Extensions',
        '7': '7. Konklusyon'
      },
      subsections: {
        '3': {
          '3.1': '3.1 Firedancer',
          '3.2': '3.2 Canonical Clients vs. Client Diversity',
          '3.3': '3.3 Protocol Incentives para sa Performant Clients'
        },
        '4': {
          '4.1': '4.1 Zones at Zone Rotation',
          '4.2': '4.2 Key Management',
          '4.3': '4.3 Zone Proposal at Activation',
          '4.4': '4.4 Zone Selection Voting Process',
          '4.5': '4.5 Global Consensus Mode'
        },
        '5': {
          '5.1': '5.1 Size at Initial Configuration',
          '5.2': '5.2 Governance at Transitions',
          '5.3': '5.3 Participation Requirements',
          '5.4': '5.4 Rationale at Network Governance'
        },
        '6': {
          '6.1': '6.1 SPL Token Fee Payment'
        }
      }
    },
    ukrainian: {
      title: 'Веб-сайт перекладу білої книги Fogo',
      subtitle: 'Отримайте доступ до білої книги блокчейну Fogo вашою улюбленою мовою',
      selectLanguage: 'Оберіть мову',
      selectSection: 'Оберіть розділ',
      sections: {
        '1': '1. Вступ',
        '2': '2. План',
        '3': '3. Протокол та Клієнти',
        '4': '4. Багатолокальний Консенсус',
        '5': '5. Набір Валідаторів',
        '6': '6. Перспективні Розширення',
        '7': '7. Висновок'
      },
      subsections: {
        '3': {
          '3.1': '3.1 Firedancer',
          '3.2': '3.2 Канонічні Клієнти vs. Різноманітність Клієнтів',
          '3.3': '3.3 Протокольні Стимули для Продуктивних Клієнтів'
        },
        '4': {
          '4.1': '4.1 Зони та Ротація Зон',
          '4.2': '4.2 Управління Ключами',
          '4.3': '4.3 Пропозиція та Активація Зони',
          '4.4': '4.4 Процес Голосування за Вибір Зони',
          '4.5': '4.5 Режим Глобального Консенсусу'
        },
        '5': {
          '5.1': '5.1 Розмір та Початкова Конфігурація',
          '5.2': '5.2 Управління та Переходи',
          '5.3': '5.3 Вимоги до Участі',
          '5.4': '5.4 Обґрунтування та Управління Мережею'
        },
        '6': {
          '6.1': '6.1 Оплата Комісії SPL Токеном'
        }
      }
    },
    portuguese: {
      title: 'Site de Tradução do White Paper Fogo',
      subtitle: 'Acesse o white paper da blockchain Fogo no seu idioma preferido',
      selectLanguage: 'Selecionar Idioma',
      selectSection: 'Selecionar Seção',
      sections: {
        '1': '1. Introdução',
        '2': '2. Esboço',
        '3': '3. Protocolo e Clientes',
        '4': '4. Consenso Multi-Local',
        '5': '5. Conjunto de Validadores',
        '6': '6. Extensões Prospectivas',
        '7': '7. Conclusão'
      },
      subsections: {
        '3': {
          '3.1': '3.1 Firedancer',
          '3.2': '3.2 Clientes Canônicos vs. Diversidade de Clientes',
          '3.3': '3.3 Incentivos de Protocolo para Clientes Performáticos'
        },
        '4': {
          '4.1': '4.1 Zonas e Rotação de Zonas',
          '4.2': '4.2 Gerenciamento de Chaves',
          '4.3': '4.3 Proposta e Ativação de Zona',
          '4.4': '4.4 Processo de Votação de Seleção de Zona',
          '4.5': '4.5 Modo de Consenso Global'
        },
        '5': {
          '5.1': '5.1 Tamanho e Configuração Inicial',
          '5.2': '5.2 Governança e Transições',
          '5.3': '5.3 Requisitos de Participação',
          '5.4': '5.4 Justificativa e Governança de Rede'
        },
        '6': {
          '6.1': '6.1 Pagamento de Taxa de Token SPL'
        }
      }
    },
    french: {
      title: 'Site Web de Traduction du Livre Blanc Fogo',
      subtitle: 'Accédez au livre blanc de la blockchain Fogo dans votre langue préférée',
      selectLanguage: 'Sélectionner la Langue',
      selectSection: 'Sélectionner la Section',
      sections: {
        '1': '1. Introduction',
        '2': '2. Plan',
        '3': '3. Protocole et Clients',
        '4': '4. Consensus Multi-Local',
        '5': '5. Ensemble de Validateurs',
        '6': '6. Extensions Prospectives',
        '7': '7. Conclusion'
      },
      subsections: {
        '3': {
          '3.1': '3.1 Firedancer',
          '3.2': '3.2 Clients Canoniques vs. Diversité des Clients',
          '3.3': '3.3 Incitations Protocolaires pour Clients Performants'
        },
        '4': {
          '4.1': '4.1 Zones et Rotation des Zones',
          '4.2': '4.2 Gestion des Clés',
          '4.3': '4.3 Proposition et Activation de Zone',
          '4.4': '4.4 Processus de Vote de Sélection de Zone',
          '4.5': '4.5 Mode de Consensus Global'
        },
        '5': {
          '5.1': '5.1 Taille et Configuration Initiale',
          '5.2': '5.2 Gouvernance et Transitions',
          '5.3': '5.3 Exigences de Participation',
          '5.4': '5.4 Justification et Gouvernance du Réseau'
        },
        '6': {
          '6.1': '6.1 Paiement de Frais de Token SPL'
        }
      }
    },
    turkish: {
      title: 'Fogo Beyaz Kağıt Çeviri Web Sitesi',
      subtitle: 'Fogo blockchain beyaz kağıdına tercih ettiğiniz dilde erişin',
      selectLanguage: 'Dil Seçin',
      selectSection: 'Bölüm Seçin',
      sections: {
        '1': '1. Giriş',
        '2': '2. Taslak',
        '3': '3. Protokol ve İstemciler',
        '4': '4. Çoklu Yerel Konsensüs',
        '5': '5. Doğrulayıcı Seti',
        '6': '6. Gelecekteki Uzantılar',
        '7': '7. Sonuç'
      },
      subsections: {
        '3': {
          '3.1': '3.1 Firedancer',
          '3.2': '3.2 Kanonik İstemciler vs. İstemci Çeşitliliği',
          '3.3': '3.3 Performanslı İstemciler için Protokol Teşvikleri'
        },
        '4': {
          '4.1': '4.1 Bölgeler ve Bölge Rotasyonu',
          '4.2': '4.2 Anahtar Yönetimi',
          '4.3': '4.3 Bölge Önerisi ve Aktivasyonu',
          '4.4': '4.4 Bölge Seçimi Oylama Süreci',
          '4.5': '4.5 Küresel Konsensüs Modu'
        },
        '5': {
          '5.1': '5.1 Boyut ve İlk Yapılandırma',
          '5.2': '5.2 Yönetişim ve Geçişler',
          '5.3': '5.3 Katılım Gereksinimleri',
          '5.4': '5.4 Gerekçe ve Ağ Yönetişimi'
        },
        '6': {
          '6.1': '6.1 SPL Token Ücret Ödemesi'
        }
      }
    },
    russian: {
      title: 'Веб-сайт перевода белой книги Fogo',
      subtitle: 'Получите доступ к белой книге блокчейна Fogo на вашем предпочитаемом языке',
      selectLanguage: 'Выберите язык',
      selectSection: 'Выберите раздел',
      sections: {
        '1': '1. Введение',
        '2': '2. План',
        '3': '3. Протокол и Клиенты',
        '4': '4. Многолокальный Консенсус',
        '5': '5. Набор Валидаторов',
        '6': '6. Перспективные Расширения',
        '7': '7. Заключение'
      },
      subsections: {
        '3': {
          '3.1': '3.1 Firedancer',
          '3.2': '3.2 Канонические Клиенты vs. Разнообразие Клиентов',
          '3.3': '3.3 Протокольные Стимулы для Производительных Клиентов'
        },
        '4': {
          '4.1': '4.1 Зоны и Ротация Зон',
          '4.2': '4.2 Управление Ключами',
          '4.3': '4.3 Предложение и Активация Зоны',
          '4.4': '4.4 Процесс Голосования за Выбор Зоны',
          '4.5': '4.5 Режим Глобального Консенсуса'
        },
        '5': {
          '5.1': '5.1 Размер и Начальная Конфигурация',
          '5.2': '5.2 Управление и Переходы',
          '5.3': '5.3 Требования к Участию',
          '5.4': '5.4 Обоснование и Управление Сетью'
        },
        '6': {
          '6.1': '6.1 Оплата Комиссии SPL Токеном'
        }
      }
    },
    hausa: {
      title: 'Gidan Yanar Gizon Fassarar Fogo White Paper',
      subtitle: 'Samun damar zuwa Fogo blockchain white paper a cikin harshen da kuke so',
      selectLanguage: 'Zaɓi Harshe',
      selectSection: 'Zaɓi Sashe',
      sections: {
        '1': '1. Gabatarwa',
        '2': '2. Tsari',
        '3': '3. Protocol da Clients',
        '4': '4. Multi-Local Consensus',
        '5': '5. Validator Set',
        '6': '6. Prospective Extensions',
        '7': '7. Kammalawa'
      },
      subsections: {
        '3': {
          '3.1': '3.1 Firedancer',
          '3.2': '3.2 Canonical Clients vs. Client Diversity',
          '3.3': '3.3 Protocol Incentives don Performant Clients'
        },
        '4': {
          '4.1': '4.1 Zones da Zone Rotation',
          '4.2': '4.2 Key Management',
          '4.3': '4.3 Zone Proposal da Activation',
          '4.4': '4.4 Zone Selection Voting Process',
          '4.5': '4.5 Global Consensus Mode'
        },
        '5': {
          '5.1': '5.1 Size da Initial Configuration',
          '5.2': '5.2 Governance da Transitions',
          '5.3': '5.3 Participation Requirements',
          '5.4': '5.4 Rationale da Network Governance'
        },
        '6': {
          '6.1': '6.1 SPL Token Fee Payment'
        }
      }
    },
    spanish: {
      title: 'Sitio Web de Traducción del Libro Blanco Fogo',
      subtitle: 'Accede al libro blanco de la blockchain Fogo en tu idioma preferido',
      selectLanguage: 'Seleccionar Idioma',
      selectSection: 'Seleccionar Sección',
      sections: {
        '1': '1. Introducción',
        '2': '2. Esquema',
        '3': '3. Protocolo y Clientes',
        '4': '4. Consenso Multi-Local',
        '5': '5. Conjunto de Validadores',
        '6': '6. Extensiones Prospectivas',
        '7': '7. Conclusión'
      },
      subsections: {
        '3': {
          '3.1': '3.1 Firedancer',
          '3.2': '3.2 Clientes Canónicos vs. Diversidad de Clientes',
          '3.3': '3.3 Incentivos de Protocolo para Clientes Performantes'
        },
        '4': {
          '4.1': '4.1 Zonas y Rotación de Zonas',
          '4.2': '4.2 Gestión de Claves',
          '4.3': '4.3 Propuesta y Activación de Zona',
          '4.4': '4.4 Proceso de Votación de Selección de Zona',
          '4.5': '4.5 Modo de Consenso Global'
        },
        '5': {
          '5.1': '5.1 Tamaño y Configuración Inicial',
          '5.2': '5.2 Gobernanza y Transiciones',
          '5.3': '5.3 Requisitos de Participación',
          '5.4': '5.4 Justificación y Gobernanza de Red'
        },
        '6': {
          '6.1': '6.1 Pago de Tarifa de Token SPL'
        }
      }
    },
    bengali: {
      title: 'ফোগো হোয়াইট পেপার অনুবাদ ওয়েবসাইট',
      subtitle: 'আপনার পছন্দের ভাষায় ফোগো ব্লকচেইন হোয়াইট পেপার অ্যাক্সেস করুন',
      selectLanguage: 'ভাষা নির্বাচন করুন',
      selectSection: 'বিভাগ নির্বাচন করুন',
      sections: {
        '1': '1. ভূমিকা',
        '2': '2. রূপরেখা',
        '3': '3. প্রোটোকল এবং ক্লায়েন্ট',
        '4': '4. বহু-স্থানীয় ঐকমত্য',
        '5': '5. ভ্যালিডেটর সেট',
        '6': '6. ভবিষ্যত সম্প্রসারণ',
        '7': '7. উপসংহার'
      },
      subsections: {
        '3': {
          '3.1': '3.1 Firedancer',
          '3.2': '3.2 ক্যানোনিকাল ক্লায়েন্ট vs. ক্লায়েন্ট বৈচিত্র্য',
          '3.3': '3.3 পারফরমেন্ট ক্লায়েন্টের জন্য প্রোটোকল প্রণোদনা'
        },
        '4': {
          '4.1': '4.1 জোন এবং জোন রোটেশন',
          '4.2': '4.2 কী ব্যবস্থাপনা',
          '4.3': '4.3 জোন প্রস্তাব এবং সক্রিয়করণ',
          '4.4': '4.4 জোন নির্বাচন ভোটিং প্রক্রিয়া',
          '4.5': '4.5 গ্লোবাল ঐকমত্য মোড'
        },
        '5': {
          '5.1': '5.1 আকার এবং প্রাথমিক কনফিগারেশন',
          '5.2': '5.2 গভর্নেন্স এবং ট্রানজিশন',
          '5.3': '5.3 অংশগ্রহণের প্রয়োজনীয়তা',
          '5.4': '5.4 যুক্তি এবং নেটওয়ার্ক গভর্নেন্স'
        },
        '6': {
          '6.1': '6.1 SPL টোকেন ফি পেমেন্ট'
        }
      }
    },
    urdu: {
      title: 'فوگو وائٹ پیپر ترجمہ ویب سائٹ',
      subtitle: 'اپنی پسندیدہ زبان میں فوگو بلاک چین وائٹ پیپر تک رسائی حاصل کریں',
      selectLanguage: 'زبان منتخب کریں',
      selectSection: 'سیکشن منتخب کریں',
      sections: {
        '1': '1. تعارف',
        '2': '2. خاکہ',
        '3': '3. پروٹوکول اور کلائنٹس',
        '4': '4. کثیر مقامی اتفاق رائے',
        '5': '5. ویلیڈیٹر سیٹ',
        '6': '6. مستقبل کی توسیعات',
        '7': '7. نتیجہ'
      },
      subsections: {
        '3': {
          '3.1': '3.1 Firedancer',
          '3.2': '3.2 کینونیکل کلائنٹس vs. کلائنٹ تنوع',
          '3.3': '3.3 کارکرد کلائنٹس کے لیے پروٹوکول ترغیبات'
        },
        '4': {
          '4.1': '4.1 زونز اور زون روٹیشن',
          '4.2': '4.2 کلیدی انتظام',
          '4.3': '4.3 زون تجویز اور فعالیت',
          '4.4': '4.4 زون انتخاب ووٹنگ عمل',
          '4.5': '4.5 عالمی اتفاق رائے موڈ'
        },
        '5': {
          '5.1': '5.1 سائز اور ابتدائی کنفیگریشن',
          '5.2': '5.2 گورننس اور تبدیلیاں',
          '5.3': '5.3 شرکت کی ضروریات',
          '5.4': '5.4 منطق اور نیٹ ورک گورننس'
        },
        '6': {
          '6.1': '6.1 SPL ٹوکن فیس ادائیگی'
        }
      }
    },
    polish: {
      title: 'Strona Tłumaczenia Białej Księgi Fogo',
      subtitle: 'Uzyskaj dostęp do białej księgi blockchain Fogo w preferowanym języku',
      selectLanguage: 'Wybierz Język',
      selectSection: 'Wybierz Sekcję',
      sections: {
        '1': '1. Wprowadzenie',
        '2': '2. Zarys',
        '3': '3. Protokół i Klienci',
        '4': '4. Konsensus Wielolokalizacyjny',
        '5': '5. Zestaw Walidatorów',
        '6': '6. Przyszłe Rozszerzenia',
        '7': '7. Wniosek'
      },
      subsections: {
        '3': {
          '3.1': '3.1 Firedancer',
          '3.2': '3.2 Klienci Kanoniczni vs. Różnorodność Klientów',
          '3.3': '3.3 Zachęty Protokołu dla Wydajnych Klientów'
        },
        '4': {
          '4.1': '4.1 Strefy i Rotacja Stref',
          '4.2': '4.2 Zarządzanie Kluczami',
          '4.3': '4.3 Propozycja i Aktywacja Strefy',
          '4.4': '4.4 Proces Głosowania Wyboru Strefy',
          '4.5': '4.5 Tryb Globalnego Konsensusu'
        },
        '5': {
          '5.1': '5.1 Rozmiar i Konfiguracja Początkowa',
          '5.2': '5.2 Zarządzanie i Przejścia',
          '5.3': '5.3 Wymagania Uczestnictwa',
          '5.4': '5.4 Uzasadnienie i Zarządzanie Siecią'
        },
        '6': {
          '6.1': '6.1 Płatność Opłaty Tokenem SPL'
        }
      }
    },
    arabic: {
      title: 'موقع ترجمة الورقة البيضاء فوغو',
      subtitle: 'الوصول إلى الورقة البيضاء لبلوك تشين فوغو بلغتك المفضلة',
      selectLanguage: 'اختر اللغة',
      selectSection: 'اختر القسم',
      sections: {
        '1': '1. مقدمة',
        '2': '2. مخطط',
        '3': '3. البروتوكول والعملاء',
        '4': '4. الإجماع متعدد المواقع',
        '5': '5. مجموعة المدققين',
        '6': '6. التوسعات المستقبلية',
        '7': '7. خاتمة'
      },
      subsections: {
        '3': {
          '3.1': '3.1 Firedancer',
          '3.2': '3.2 العملاء المعياريون vs. تنوع العملاء',
          '3.3': '3.3 حوافز البروتوكول للعملاء عالي الأداء'
        },
        '4': {
          '4.1': '4.1 المناطق ودوران المناطق',
          '4.2': '4.2 إدارة المفاتيح',
          '4.3': '4.3 اقتراح وتفعيل المنطقة',
          '4.4': '4.4 عملية التصويت لاختيار المنطقة',
          '4.5': '4.5 وضع الإجماع العالمي'
        },
        '5': {
          '5.1': '5.1 الحجم والتكوين الأولي',
          '5.2': '5.2 الحوكمة والانتقالات',
          '5.3': '5.3 متطلبات المشاركة',
          '5.4': '5.4 المنطق وحوكمة الشبكة'
        },
        '6': {
          '6.1': '6.1 دفع رسوم رمز SPL'
        }
      }
    },
    persian: {
      title: 'وب‌سایت ترجمه مقاله سفید فوگو',
      subtitle: 'به مقاله سفید بلاک‌چین فوگو به زبان مورد علاقه خود دسترسی پیدا کنید',
      selectLanguage: 'انتخاب زبان',
      selectSection: 'انتخاب بخش',
      sections: {
        '1': '1. مقدمه',
        '2': '2. طرح کلی',
        '3': '3. پروتکل و کلاینت‌ها',
        '4': '4. اجماع چند محلی',
        '5': '5. مجموعه اعتبارسنج',
        '6': '6. توسعه‌های آینده',
        '7': '7. نتیجه‌گیری'
      },
      subsections: {
        '3': {
          '3.1': '3.1 Firedancer',
          '3.2': '3.2 کلاینت‌های کانونیک در مقابل تنوع کلاینت',
          '3.3': '3.3 انگیزه‌های پروتکل برای کلاینت‌های پرکارآمد'
        },
        '4': {
          '4.1': '4.1 مناطق و چرخش مناطق',
          '4.2': '4.2 مدیریت کلید',
          '4.3': '4.3 پیشنهاد و فعال‌سازی منطقه',
          '4.4': '4.4 فرآیند رأی‌گیری انتخاب منطقه',
          '4.5': '4.5 حالت اجماع جهانی'
        },
        '5': {
          '5.1': '5.1 اندازه و پیکربندی اولیه',
          '5.2': '5.2 حاکمیت و انتقال‌ها',
          '5.3': '5.3 الزامات مشارکت',
          '5.4': '5.4 منطق و حاکمیت شبکه'
        },
        '6': {
          '6.1': '6.1 پرداخت کارمزد توکن SPL'
        }
      }
    }
  };

  const currentTranslations = translations[selectedLanguage] || translations['english'];
  const selectedLanguageInfo = languages.find(lang => lang.code === selectedLanguage);
  const currentSubsections = currentTranslations.subsections?.[selectedSection] || {};
  const hasSubsections = Object.keys(currentSubsections).length > 0;

  const getContent = () => {
    if (selectedSection === '1') {
      return introductionContent[selectedLanguage] || introductionContent.english;
    }
    
    if (selectedSection === '2') {
      return outlineContent[selectedLanguage] || outlineContent.english;
    }
    
    if (selectedSection === '3' && !selectedSubsection) {
      return protocolClientsContent[selectedLanguage] || protocolClientsContent.english;
    }
    
    if (selectedSection === '3' && selectedSubsection === '3.1') {
      return firedancerContent[selectedLanguage] || firedancerContent.english;
    }
    
    if (selectedSection === '3' && selectedSubsection === '3.2') {
      return clientDiversityContent[selectedLanguage] || clientDiversityContent.english;
    }
    
    if (selectedSection === '3' && selectedSubsection === '3.3') {
      return protocolIncentivesContent[selectedLanguage] || protocolIncentivesContent.english;
    }
    
    if (selectedSection === '4' && !selectedSubsection) {
      return multiLocalConsensusContent[selectedLanguage] || multiLocalConsensusContent.english;
    }
    
    if (selectedSubsection && currentSubsections[selectedSubsection]) {
      return `Content for ${currentSubsections[selectedSubsection]} will be available soon.`;
    }
    
    return `Content for ${currentTranslations.sections?.[selectedSection]} will be available soon.`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-6">
            <Globe className="w-12 h-12 text-blue-400 mr-4" />
            <h1 className="text-4xl md:text-5xl font-bold text-white">
              {currentTranslations.title}
            </h1>
          </div>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            {currentTranslations.subtitle}
          </p>
        </div>

        {/* Language Selector */}
        <div className="max-w-md mx-auto mb-8">
          <label className="block text-sm font-medium text-gray-300 mb-2">
            {currentTranslations.selectLanguage}
          </label>
          <div className="relative">
            <button
              onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              className="w-full bg-slate-800 border border-slate-600 rounded-lg px-4 py-3 text-left text-white hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 flex items-center justify-between"
            >
              <span>
                {selectedLanguageInfo ? `${selectedLanguageInfo.nativeName} (${selectedLanguageInfo.name})` : 'Select Language'}
              </span>
              <ChevronDown className={`w-5 h-5 transition-transform ${isDropdownOpen ? 'rotate-180' : ''}`} />
            </button>
            
            {isDropdownOpen && (
              <div className="absolute z-10 w-full mt-1 bg-slate-800 border border-slate-600 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                {languages.map((language) => (
                  <button
                    key={language.code}
                    onClick={() => {
                      setSelectedLanguage(language.code);
                      setIsDropdownOpen(false);
                    }}
                    className="w-full px-4 py-3 text-left text-white hover:bg-slate-700 focus:outline-none focus:bg-slate-700 border-b border-slate-600 last:border-b-0"
                  >
                    <div className="font-medium">{language.nativeName}</div>
                    <div className="text-sm text-gray-400">{language.name}</div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Section Selector */}
        <div className="max-w-4xl mx-auto mb-8">
          <h2 className="text-2xl font-bold text-white mb-6 text-center">
            {currentTranslations.selectSection}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            {currentTranslations.sections && Object.entries(currentTranslations.sections).map(([key, value]) => (
              <label key={key} className="cursor-pointer">
                <input
                  type="radio"
                  name="section"
                  value={key}
                  checked={selectedSection === key}
                  onChange={(e) => {
                    setSelectedSection(e.target.value);
                    setSelectedSubsection('');
                  }}
                  className="sr-only"
                />
                <div className={`p-4 rounded-lg border-2 transition-all duration-200 ${
                  selectedSection === key
                    ? 'border-blue-500 bg-blue-500/20 text-white'
                    : 'border-slate-600 bg-slate-800 text-gray-300 hover:border-slate-500 hover:bg-slate-700'
                }`}>
                  <FileText className="w-6 h-6 mb-2" />
                  <div className="font-medium">{value}</div>
                </div>
              </label>
            ))}
          </div>
          
          {/* Subsection Selector */}
          {hasSubsections && (
            <div>
              <h3 className="text-xl font-bold text-white mb-4 text-center">
                Subsections
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {Object.entries(currentSubsections).map(([key, value]) => (
                  <label key={key} className="cursor-pointer">
                    <input
                      type="radio"
                      name="subsection"
                      value={key}
                      checked={selectedSubsection === key}
                      onChange={(e) => setSelectedSubsection(e.target.value)}
                      className="sr-only"
                    />
                    <div className={`p-3 rounded-lg border-2 transition-all duration-200 text-sm ${
                      selectedSubsection === key
                        ? 'border-blue-500 bg-blue-500/20 text-white'
                        : 'border-slate-600 bg-slate-800 text-gray-300 hover:border-slate-500 hover:bg-slate-700'
                    }`}>
                      <div className="font-medium">{value}</div>
                    </div>
                  </label>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Content Display */}
        <div className="max-w-4xl mx-auto">
          <div className="bg-slate-800 rounded-lg p-8 border border-slate-600">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-white">
                {selectedSubsection 
                  ? currentSubsections[selectedSubsection]
                  : currentTranslations.sections?.[selectedSection]
                }
              </h3>
              <span className="text-sm text-gray-400">
                {selectedLanguageInfo?.nativeName}
              </span>
            </div>
            <div className="prose prose-invert max-w-none">
              <div className="text-gray-300 leading-relaxed whitespace-pre-line">
                {getContent()}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;